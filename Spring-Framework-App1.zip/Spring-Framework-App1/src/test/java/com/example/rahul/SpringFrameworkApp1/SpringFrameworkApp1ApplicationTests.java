package com.example.rahul.SpringFrameworkApp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFrameworkApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
