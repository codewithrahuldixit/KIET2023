package com.example.rahul.SpringFrameworkApp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFrameworkApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringFrameworkApp1Application.class, args);
	}

}
